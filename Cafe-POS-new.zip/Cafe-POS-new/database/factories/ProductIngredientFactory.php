<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\ProductIngredient;
use Faker\Generator as Faker;

$factory->define(ProductIngredient::class, function (Faker $faker) {
    return [
        //
    ];
});
