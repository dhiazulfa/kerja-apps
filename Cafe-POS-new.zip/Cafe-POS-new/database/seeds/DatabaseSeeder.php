<?php

use App\Enums\UserRole;
use App\User;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        User::insert([[
            'name' => 'Admin',
            'username' => 'admin',
            'role' => UserRole::Administrator,
            'password' => Hash::make('password'),
        ], [
            'name' => 'Cashier',
            'username' => 'cashier',
            'role' => UserRole::Cashier,
            'password' => Hash::make('password'),
        ], [
            'name' => 'Owner',
            'username' => 'owner',
            'role' => UserRole::Owner,
            'password' => Hash::make('password'),
        ]]);
    }
}
