<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class IngredientInput extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'ingredient_id',
        'quantity',
        'price',
        'inputted_by',
    ];

    public function ingredient()
    {
        return $this->belongsTo(Ingredient::class);
    }

    public function inputtedBy()
    {
        return $this->belongsTo(User::class, 'inputted_by');
    }
}
