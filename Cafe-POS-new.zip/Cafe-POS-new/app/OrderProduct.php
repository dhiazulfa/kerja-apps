<?php

namespace App;

use App\Enums\OrderStatus;
use Illuminate\Database\Eloquent\Relations\Pivot;

class OrderProduct extends Pivot
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'order_id',
        'product_id',
        'product_snapshot',
        'quantity',
        'total_price',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'product_snapshot' => 'array',
    ];

    protected static function boot()
    {
        parent::boot();

        static::creating(function (OrderProduct $model) {
            $product = Product::find($model->product_id);

            $model->product_snapshot = $product->toArray();
            $model->total_price = $product->price * $model->quantity;
        });
    }
}
