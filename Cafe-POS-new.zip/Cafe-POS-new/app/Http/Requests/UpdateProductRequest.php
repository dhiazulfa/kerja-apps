<?php

namespace App\Http\Requests;

use App\Enums\ProductType;
use App\Enums\UserRole;
use BenSampo\Enum\Rules\EnumValue;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rule;

class UpdateProductRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return Auth::check() && Auth::user()->role->is(UserRole::Administrator);
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'name' => ['required', 'string', Rule::unique('products')->ignore($this->route('product'))],
            'price' => ['required', 'integer', 'gte:0'],
            'photo_file' => ['nullable', 'file', 'image', 'max:1024'],
            'type' => ['required', new EnumValue(ProductType::class)],
            'ingredients' => ['required', 'array', 'min:1'],
            'ingredients.*.id' => ['required', 'exists:ingredients,id'],
            'ingredients.*.quantity' => ['required', 'integer', 'gt:0'],
        ];
    }
}
