<?php

namespace App\Http\Controllers;

class CashierController extends Controller
{
    //
}
