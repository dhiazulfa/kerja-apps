<?php

namespace App\Http\Controllers;

use App\Enums\UserRole;
use App\Http\Requests\LoginRequest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller
{
    public function showLoginPage(Request $request)
    {
        return view('auth.login');
    }

    public function login(LoginRequest $request)
    {
        $credentials = $request->only(['username', 'password']);

        if (! Auth::guard('web')->attempt($credentials)) {
            return redirect()->route('auth.login')->withInput(['username'])->with([
                'alert' => [
                    'type' => 'danger',
                    'color' => '',
                    'text' => 'Username atau Password salah!',
                ],
            ]);
        }

        if (Auth::user()->role->is(UserRole::Administrator)) {
            return redirect()->route('admin.dashboard');
        }

        return redirect()->route('orders.list');
    }

    public function logout(Request $request)
    {
        if (Auth::check()) {
            Auth::logout();
        }

        return redirect()->route('auth.login');
    }
}
