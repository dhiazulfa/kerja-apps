<?php

namespace App\Http\Controllers;

use App\Http\Requests\AddOrderItemsRequest;
use App\Http\Requests\CreateOrderRequest;
use App\Http\Requests\UpdateOrderItemsRequest;
use App\IngredientOutput;
use App\Order;
use App\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;

class OrderController extends Controller
{
    public function showOrderListPage(Request $request)
    {
        return view('order.list', ['orders' => Order::latest()->paginate()]);
    }

    public function showCreateOrderPage(Request $request)
    {
        return view('order.create', [
            'products' => Product::all()->groupBy(function (Product $model) {
                return $model->type->value;
            }),
            'orderItems' => collect(Session::get('order.items'))->map(function ($item) {
                $model = Product::find($item['id']);

                return $item + [
                        'total_price' => $model->price * $item['quantity'],
                        'name' => $model->name,
                    ];
            }),
        ]);
    }

    public function createOrder(CreateOrderRequest $request)
    {
        $totalPrice = 0;
        $products = [];

        foreach ($request->input('products') as $product) {
            $products[$product['id']] = [
                'quantity' => $product['quantity'],
            ];

            $productModel = Product::find($product['id']);

            $totalPrice += $productModel->price * (int)$product['quantity'];
        }

        $input = $request->only(['customer_name', 'note']);
        $tax = config('cafe.order_tax', 10);
        $taxPrice = ($tax / 100) * $totalPrice;

        $order = Order::create([
                'user_id' => Auth::user()->id,
                'tax' => $tax,
                'total_price' => $totalPrice + $taxPrice,
            ] + $input);

        $order->products()->sync($products);

        foreach ($order->products()->get() as $product) {
            foreach ($product->ingredients as $ingredient) {
                $ingredient->decrement('current_stock', $ingredient->pivot->quantity);

                IngredientOutput::create([
                    'quantity' => $ingredient->pivot->quantity * $product->pivot->quantity,
                    'ingredient_id' => $ingredient->id,
                    'order_id' => $order->id,
                    'product_id' => $product->id,
                ]);
            }
        }

        Session::remove('order.items');

        return redirect()->back();
    }

    public function addOrderItems(AddOrderItemsRequest $request)
    {
        if (! Session::exists('order.items')) {
            Session::put('order.items', []);
        }

        $items = collect(Session::pull('order.items'));

        foreach ($request->input('products') as $product) {
            if ($items->where('id', $product['id'])->isEmpty()) {
                $items->push([
                    'id' => $product['id'],
                    'quantity' => 0,
                ]);
            }
        }

        return $this->putOrderItems($items, $request);
    }

    protected function putOrderItems(Collection $items, Request $request)
    {
        Session::put('order.items', $items->map(function ($item, $key) use ($request) {
            foreach ($request->input('products') as $product) {
                if ($item['id'] == $product['id']) {
                    return [
                        'id' => $item['id'],
                        'quantity' => $item['quantity'] + (int)$product['quantity'],
                    ];
                }
            }

            return $item;
        })->toArray());

        return redirect()->back();
    }

    public function updateOrderItems(UpdateOrderItemsRequest $request)
    {
        $items = collect([]);
        $products = collect($request->input('products'))->filter(function ($item, $key) {
            return (int)$item['quantity'] > 0;
        });

        foreach ($products->toArray() as $product) {
            if ($items->where('id', $product['id'])->isEmpty()) {
                $items->push([
                    'id' => $product['id'],
                    'quantity' => 0,
                ]);
            }
        }

        return $this->putOrderItems($items, $request);
    }

    public function resetOrderItems(Request $request)
    {
        Session::remove('order.items');

        return redirect()->back();
    }

    public function print(Request $request, Order $order)
    {
        return view('order.print', compact('order'));
    }
}
