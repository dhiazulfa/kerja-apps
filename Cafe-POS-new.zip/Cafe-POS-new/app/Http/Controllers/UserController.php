<?php

namespace App\Http\Controllers;

use App\Enums\UserRole;
use App\Http\Controllers\Controller;
use App\Http\Requests\CreateUserRequest;
use App\Http\Requests\UpdateUserPasswordRequest;
use App\Http\Requests\UpdateUserRequest;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;

class UserController extends Controller
{
    public function showUserListPage(Request $request)
    {
        return view('admin.user.list', ['users' => User::paginate()]);
    }

    public function showCreateUserPage(Request $request)
    {
        return view('admin.user.create', ['roles' => UserRole::asSelectArray()]);
    }

    public function createUser(CreateUserRequest $request)
    {
        $input = $request->merge([
            'password' => Hash::make($request->post('password')),
        ])->only(['name', 'username', 'password', 'role']);

        if ($request->hasFile('photo_file')) {
            $input['photo_path'] = $request->file('photo_file')->store('photos/users');
        }

        $user = User::create($input);

        return redirect()->route('admin.users.edit', ['user' => $user]);
    }

    public function showEditUserPage(Request $request, User $user)
    {
        return view('admin.user.edit', ['user' => $user, 'roles' => UserRole::asSelectArray()]);
    }

    public function updateUser(UpdateUserRequest $request, User $user)
    {
        $input = $request->only(['name', 'username', 'role']);

        if ($request->hasFile('photo_file')) {
            $input['photo_path'] = $request->file('photo_file')->store('photos/users');

            if ($user->hasPhoto()) {
                Storage::delete($user->photo_path);
            }
        }

        $user->update($input);

        return redirect()->route('admin.users.edit', ['user' => $user]);
    }

    public function updateUserPassword(UpdateUserPasswordRequest $request, User $user)
    {
        $user->update([
            'password' => Hash::make($request->input('password')),
        ]);

        return redirect()->route('admin.users.edit', ['user' => $user]);
    }

    public function deleteUser(Request $request, User $user)
    {
        $user->forceDelete();

        return redirect()->route('admin.users.list');
    }
}
