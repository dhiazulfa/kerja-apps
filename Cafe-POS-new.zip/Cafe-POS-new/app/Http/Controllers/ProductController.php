<?php

namespace App\Http\Controllers;

use App\Http\Requests\CreateProductRequest;
use App\Http\Requests\UpdateProductRequest;
use App\Ingredient;
use App\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class ProductController extends Controller
{
    public function showProductListPage(Request $request)
    {
        return view('admin.product.list', ['products' => Product::paginate()]);
    }

    public function showCreateProductPage(Request $request)
    {
        return view('admin.product.create', ['ingredients' => Ingredient::all()]);
    }

    public function createProduct(CreateProductRequest $request)
    {
        $input = $request->only(['name', 'price', 'type']);

        if ($request->hasFile('photo_file')) {
            $input['photo_path'] = $request->file('photo_file')->store('photos/products');
        }

        $product = Product::create($input);

        $ingredients = [];

        foreach ($request->input('ingredients') as $ingredient) {
            $ingredients[$ingredient['id']] = [
                'quantity' => $ingredient['quantity'],
            ];
        }

        $product->ingredients()->sync($ingredients);

        return redirect()->route('admin.products.edit', ['product' => $product]);
    }

    public function showEditProductPage(Request $request, Product $product)
    {
        return view('admin.product.edit', ['product' => $product, 'ingredients' => Ingredient::all()]);
    }

    public function updateProduct(UpdateProductRequest $request, Product $product)
    {
        $input = $request->only(['name', 'price', 'type']);

        if ($request->hasFile('photo_file')) {
            $input['photo_path'] = $request->file('photo_file')->store('photos/products');

            if ($product->hasPhoto()) {
                Storage::delete($product->photo_path);
            }
        }

        $product->update($input);

        $ingredients = [];

        foreach ($request->input('ingredients') as $ingredient) {
            $ingredients[$ingredient['id']] = [
                'quantity' => $ingredient['quantity'],
            ];
        }

        $product->ingredients()->sync($ingredients);

        return redirect()->route('admin.products.edit', ['product' => $product]);
    }

    public function deleteProduct(Request $request, Product $product)
    {
        $product->ingredients()->detach();

        $product->forceDelete();

        return redirect()->route('admin.products.list');
    }
}
