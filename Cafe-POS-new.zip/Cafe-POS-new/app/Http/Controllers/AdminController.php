<?php

namespace App\Http\Controllers;

use App\IngredientInput;
use App\IngredientOutput;
use App\Order;
use App\Product;
use Illuminate\Http\Request;

class AdminController extends Controller
{
    public function showDashboardPage(Request $request)
    {
        // Total pemasukan per bulan dari pesananan
        $incomes = Order::selectRaw('MONTH(created_at) month, sum(total_price) data')->whereYear('created_at', date('Y'))->groupBy('month')->orderBy('month', 'desc')->get();

        // Jumlah pesanan dibuat per bulan
        $orders = Order::selectRaw('MONTH(created_at) month, count(*) data')->whereYear('created_at', date('Y'))->groupBy('month')->orderBy('month', 'desc')->get();

        // Pemasukan bahan bulan ini
        $ingredientInput = IngredientInput::whereYear('created_at', date('Y'))->whereMonth('created_at', date('m'))->get()->groupBy(function (IngredientInput $model) {
            return $model->ingredient->name;
        })->map->sum('quantity');

        // Pengeluaran/pemakaian bahan bulan ini
        $ingredientOutput = IngredientOutput::whereYear('created_at', date('Y'))->whereMonth('created_at', date('m'))->get()->groupBy(function (IngredientOutput $model) {
            return $model->ingredient->name;
        })->map->sum('quantity');

        // Jumlah produk yang disediakan
        $products = Product::count();

        return view('admin.dashboard', [
            'incomes' => $incomes,
            'orders' => $orders,
            'ingredientInput' => $ingredientInput,
            'ingredientOutput' => $ingredientOutput,
            'products' => $products,
        ]);
    }
}
