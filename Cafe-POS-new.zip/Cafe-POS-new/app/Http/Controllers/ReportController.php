<?php

namespace App\Http\Controllers;

use App\IngredientInput;
use App\IngredientOutput;
use App\Order;
use App\OrderProduct;

class ReportController extends Controller
{
    public function reportMonthly()
    {
        // Total pesanan bulan ini
        $orders = Order::whereYear('created_at', date('Y'))->whereMonth('created_at', date('m'))->orderBy('created_at');
        $totalOrders = $orders->count();
        $income = $orders->sum('total_price');

        // Menu yang banyak dipesan
        $orderProducts = OrderProduct::whereYear('created_at', date('Y'))->whereMonth('created_at', date('m'))->get()->groupBy(function (OrderProduct $model) {
            return $model->product_snapshot["name"];
        })->map->sum('quantity')->sortDesc();

        // Jumlah bahan yang masuk
        $ingredientInputs = IngredientInput::whereYear('created_at', date('Y'))->whereMonth('created_at', date('m'))->orderBy('created_at')->get()->groupBy(function (IngredientInput $model) {
            return $model->ingredient->name;
        })->map->sum('quantity')->sortDesc();

        $ingredientInputCost = IngredientInput::whereYear('created_at', date('Y'))->whereMonth('created_at', date('m'))->sum('price');

        // Jumlah bahan yang keluar
        $ingredientOutputs = IngredientOutput::whereYear('created_at', date('Y'))->whereMonth('created_at', date('m'))->orderBy('created_at')->get()->groupBy(function (IngredientOutput $model) {
            return $model->ingredient->name;
        })->map->sum('quantity')->sortDesc();

        return view('report', compact('totalOrders', 'income', 'ingredientInputCost', 'ingredientInputs', 'ingredientOutputs', 'orderProducts'));
    }
}
