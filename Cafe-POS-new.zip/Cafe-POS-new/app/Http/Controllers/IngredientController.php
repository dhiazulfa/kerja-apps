<?php

namespace App\Http\Controllers;

use App\Http\Requests\CreateIngredientInputRequest;
use App\Http\Requests\CreateIngredientRequest;
use App\Http\Requests\UpdateIngredientRequest;
use App\Ingredient;
use App\IngredientInput;
use App\IngredientOutput;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;

class IngredientController extends Controller
{
    public function showIngredientListPage(Request $request)
    {
        return view('admin.ingredient.list', ['ingredients' => Ingredient::latest()->paginate()]);
    }

    public function showCreateIngredientPage(Request $request)
    {
        return view('admin.ingredient.create');
    }

    public function createIngredient(CreateIngredientRequest $request)
    {
        $input = $request->only(['name']);

        if ($request->hasFile('photo_file')) {
            $input['photo_path'] = $request->file('photo_file')->store('photos/ingredients');
        }

        $ingredient = Ingredient::create($input);

        return redirect()->route('admin.ingredients.edit', ['ingredient' => $ingredient]);
    }

    public function showEditIngredientPage(Request $request, Ingredient $ingredient)
    {
        return view('admin.ingredient.edit', ['ingredient' => $ingredient]);
    }

    public function updateIngredient(UpdateIngredientRequest $request, Ingredient $ingredient)
    {
        $input = $request->only(['name']);

        if ($request->hasFile('photo_file')) {
            $input['photo_path'] = $request->file('photo_file')->store('photos/users');

            if ($ingredient->hasPhoto()) {
                Storage::delete($ingredient->photo_path);
            }
        }

        $ingredient->update($input);

        return redirect()->route('admin.ingredients.edit', ['ingredient' => $ingredient]);
    }

    public function deleteIngredient(Request $request, Ingredient $ingredient)
    {
        if ($ingredient->hasPhoto()) {
            Storage::delete($ingredient->photo_path);
        }

        $ingredient->forceDelete();

        return redirect()->route('admin.ingredients.list');
    }

    public function showIngredientInputListPage(Request $request)
    {
        return view('admin.ingredient.input.list', ['ingredientInputs' => IngredientInput::latest()->paginate()]);
    }

    public function showCreateIngredientInputPage(Request $request)
    {
        return view('admin.ingredient.input.create', ['ingredients' => Ingredient::orderBy('name')->get()]);
    }

    public function createIngredientInput(CreateIngredientInputRequest $request)
    {
        $input = $request->only(['ingredient_id', 'quantity', 'price']);

        $ingredientInput = IngredientInput::create([
                'inputted_by' => Auth::user()->id,
            ] + $input);

        $ingredientInput->ingredient()->increment('current_stock', $ingredientInput->quantity);

        return redirect()->route('admin.ingredients.inputs.list');
    }

    public function showIngredientOutputListPage(Request $request)
    {
        return view('admin.ingredient.output.list', ['ingredientOutputs' => IngredientOutput::latest()->paginate()]);
    }
}
