<?php

namespace App;

use App\Enums\ProductType;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Storage;

class Product extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name',
        'price',
        'photo_path',
        'type',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'price' => 'decimal:0',
        'type' => ProductType::class,
    ];

    /**
     * Check that product has valid photo.
     *
     * @return bool
     */
    public function hasPhoto()
    {
        return $this->photo_path && Storage::exists($this->photo_path);
    }

    public function ingredients()
    {
        return $this->belongsToMany(Ingredient::class, 'product_ingredient')
            ->using(ProductIngredient::class)
            ->withPivot(['quantity'])
            ->withTimestamps();
    }

    public function getIsAvailableAttribute()
    {
        foreach ($this->ingredients as $ingredient) {
            if ($ingredient->current_stock < $ingredient->pivot->quantity) {
                return false;
            }
        }

        return true;
    }

    public function getInsufficientIngredientNameAttribute()
    {
        foreach ($this->ingredients as $ingredient) {
            if ($ingredient->current_stock < $ingredient->pivot->quantity) {
                return $ingredient->name;
            }
        }

        return null;
    }
}
