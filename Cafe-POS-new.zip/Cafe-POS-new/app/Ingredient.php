<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Storage;

class Ingredient extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name',
        'current_stock',
        'photo_path',
    ];

    /**
     * Check that ingredient has valid photo.
     *
     * @return bool
     */
    public function hasPhoto()
    {
        return $this->photo_path && Storage::exists($this->photo_path);
    }

    public function products()
    {
        return $this->belongsToMany(Product::class, 'product_ingredient');
    }
}
