<?php

namespace App\Enums;

use BenSampo\Enum\Enum;

/**
 * @method static static Administrator()
 * @method static static Cashier()
 * @method static static Owner()
 */
final class UserRole extends Enum
{
    const Administrator = 'admin';
    const Cashier = 'cashier';
    const Owner = 'owner';
}
