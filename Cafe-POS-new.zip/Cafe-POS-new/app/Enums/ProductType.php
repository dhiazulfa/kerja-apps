<?php

namespace App\Enums;

use BenSampo\Enum\Enum;

/**
 * @method static static Food()
 * @method static static Drink()
 */
final class ProductType extends Enum
{
    const Food = 'food';
    const Drink = 'drink';
}
