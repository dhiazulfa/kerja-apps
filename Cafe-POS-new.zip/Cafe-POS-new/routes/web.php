<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\IngredientController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\ReportController;
use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::redirect('/', '/orders');

Route::prefix('/login')->middleware(['guest:web'])->group(function () {
    Route::get('/', [AuthController::class, 'showLoginPage'])->name('auth.login');
    Route::post('/', [AuthController::class, 'login'])->middleware(['throttle:5,1']);
});

Route::post('/logout', [AuthController::class, 'logout'])->name('auth.logout');

Route::prefix('/admin')->name('admin.')->middleware(['auth:web'])->group(function () {
    Route::get('/', [AdminController::class, 'showDashboardPage'])->name('dashboard');

    Route::prefix('/products')->name('products.')->group(function () {
        Route::get('/', [ProductController::class, 'showProductListPage'])->name('list');

        Route::prefix('/create')->group(function () {
            Route::get('/', [ProductController::class, 'showCreateProductPage'])->name('new');
            Route::post('/', [ProductController::class, 'createProduct'])->name('create');
        });

        Route::prefix('/{product}')->group(function () {
            Route::get('/', [ProductController::class, 'showEditProductPage'])->name('edit');
            Route::patch('/', [ProductController::class, 'updateProduct'])->name('update');
            Route::delete('/', [ProductController::class, 'deleteProduct'])->name('delete');
        });
    });

    Route::prefix('/ingredients')->name('ingredients.')->group(function () {
        Route::get('/', [IngredientController::class, 'showIngredientListPage'])->name('list');

        Route::prefix('/create')->group(function () {
            Route::get('/', [IngredientController::class, 'showCreateIngredientPage'])->name('new');
            Route::post('/', [IngredientController::class, 'createIngredient'])->name('create');
        });

        Route::prefix('/inputs')->name('inputs.')->group(function () {
            Route::get('/', [IngredientController::class, 'showIngredientInputListPage'])->name('list');

            Route::prefix('/create')->group(function () {
                Route::get('/', [IngredientController::class, 'showCreateIngredientInputPage'])->name('new');
                Route::post('/', [IngredientController::class, 'createIngredientInput'])->name('create');
            });
        });

        Route::get('/outputs', [IngredientController::class, 'showIngredientOutputListPage'])->name('outputs.list');

        Route::prefix('/{ingredient}')->group(function () {
            Route::get('/', [IngredientController::class, 'showEditIngredientPage'])->name('edit');
            Route::patch('/', [IngredientController::class, 'updateIngredient'])->name('update');
            Route::delete('/', [IngredientController::class, 'deleteIngredient'])->name('delete');
        });
    });

    Route::prefix('/users')->name('users.')->group(function () {
        Route::get('/', [UserController::class, 'showUserListPage'])->name('list');

        Route::prefix('/create')->group(function () {
            Route::get('/', [UserController::class, 'showCreateUserPage'])->name('new');
            Route::post('/', [UserController::class, 'createUser'])->name('create');
        });

        Route::prefix('/{user}')->group(function () {
            Route::get('/', [UserController::class, 'showEditUserPage'])->name('edit');
            Route::patch('/', [UserController::class, 'updateUser'])->name('update');
            Route::delete('/', [UserController::class, 'deleteUser'])->name('delete');

            Route::patch('/password', [UserController::class, 'updateUserPassword'])->name('update-password');
        });
    });
});

Route::prefix('/orders')->name('orders.')->group(function () {
    Route::get('/', [OrderController::class, 'showOrderListPage'])->name('list');

    Route::prefix('/create')->group(function () {
        Route::get('/', [OrderController::class, 'showCreateOrderPage'])->name('new');
        Route::post('/', [OrderController::class, 'createOrder'])->name('create');
    });

    Route::prefix('/items')->name('items.')->group(function () {
        Route::post('/', [OrderController::class, 'addOrderItems'])->name('add');
        Route::patch('/', [OrderController::class, 'updateOrderItems'])->name('update');
        Route::delete('/', [OrderController::class, 'resetOrderItems'])->name('reset');
    });

    Route::get('/{order}', [OrderController::class, 'print'])->name('print');
});

Route::get('/report', [ReportController::class, 'reportMonthly']);
