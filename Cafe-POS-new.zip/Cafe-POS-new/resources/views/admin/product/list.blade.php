@extends('layouts.app')

@section('head:title', 'Daftar Produk')

@section('sidebar:products', 'active')

@section('app:content')
    @include('includes.header', ['title' => 'Daftar Produk', 'paragraph' => 'Daftar produk yang akan di tampilkan di menu'])

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <div class="col-sm-12 d-flex justify-content-end">
                        <a href="{{ route('admin.products.create') }}" class="btn btn-success me-1 mb-1">Buat Produk</a>
                    </div>
                </div>
                <div class="card-content">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead>
                            <tr>
                                <th>FOTO</th>
                                <th>NAMA PRODUK</th>
                                <th class="text-center">HARGA PRODUK</th>
                                <th class="text-center">JENIS</th>
                                <th class="text-center">AKSI</th>
                            </tr>
                            </thead>
                            <tbody>
                            @forelse($products as $product)
                                <tr>
                                    <th>
                                        <div class="avatar @unless($product->hasPhoto()) bg-warning @endif avatar-lg ">
                                            @if($product->hasPhoto())
                                                <img src="{{ asset($product->photo_path) }}" alt="{{ $product->name }}">
                                            @else
                                                <div class="avatar-content">
                                                    <i data-feather="image" width="20"></i>
                                                </div>
                                            @endif
                                        </div>
                                    </th>
                                    <td>{{ $product->name }}</td>
                                    <td class="text-center">Rp {{ number_format($product->price) }}</td>
                                    <td class="text-center">{{ $product->type->key }}</td>
                                    <td class="text-center">
                                        <a href="{{ route('admin.products.edit', compact('product')) }}" class="btn icon btn-outline-info">
                                            <i data-feather="edit" width="20"></i>
                                        </a>

                                        <form class="d-none" action="{{ route('admin.products.delete', compact('product')) }}" method="post" id="form-delete-{{ $product->id }}">
                                            @csrf
                                            @method('DELETE')
                                        </form>

                                        <a href="{{ route('admin.products.delete', compact('product')) }}" class="btn icon btn-outline-danger" onclick="event.preventDefault(); confirm('Apakah anda yakin ingin menghapus produk ini?') && document.querySelector('#form-delete-{{ $product->id }}').submit();">
                                            <i data-feather="trash" width="20"></i>
                                        </a>
                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <th class="text-center" colspan="5">
                                        <span>Produk kosong</span>
                                    </th>
                                </tr>
                            @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            {{ $products->links() }}
        </div>
    </div>
@endsection
