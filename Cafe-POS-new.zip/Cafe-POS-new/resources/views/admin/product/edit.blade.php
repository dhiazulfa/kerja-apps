@php use App\Enums\ProductType; @endphp
@extends('layouts.app')

@section('head:title', 'Ubah Produk')

@section('sidebar:products', 'active')

@push('head:scripts')
    <link href="{{ asset('assets/vendors/choices.js/choices.min.css') }}" rel="stylesheet">
@endpush

@section('app:content')
    @include('includes.header', ['title' => 'Ubah Produk', 'paragraph' => 'Ubah produk yang ditampilkan di menu pesanan'])

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4>Form Ubah Produk</h4>
                </div>
                <div class="card-body">

                    <form class="form form-horizontal" action="{{ route('admin.products.update', compact('product')) }}" method="post" enctype="multipart/form-data">
                        @csrf
                        @method('PATCH')

                        <div class="form-body">
                            <div class="row">
                                <div class="col-md-4">
                                    <label for="name">Nama Produk</label>
                                </div>
                                <div class="col-md-8 form-group mb-4">
                                    <input type="text" id="name" class="form-control @error('name') is-invalid @enderror" name="name" placeholder="cth: Kopi Andalan" required value="{{ $product->name }}">
                                    @error('name')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                    @enderror
                                </div>

                                <div class="col-md-4">
                                    <label for="type">Jenis Produk</label>
                                </div>
                                <div class="col-md-8 form-group mb-4">
                                    <div class="@error('type') is-invalid @enderror">
                                        <select class="choices form-select" name="type" id="type">
                                            @foreach(ProductType::asSelectArray() as $key => $val)
                                                <option value="{{ $key }}" @if($product->type->is($key)) selected @endif>{{ $val }}</option>
                                            @endforeach
                                        </select>
                                    </div>

                                    @error('type')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                    @enderror
                                </div>

                                <div class="col-md-4">
                                    <label for="price">Harga</label>
                                </div>
                                <div class="col-md-8 form-group mb-4">
                                    <input type="number" min="0" id="price" class="form-control @error('price') is-invalid @enderror" name="price" placeholder="cth: 1000" required value="{{ $product->price }}">
                                    @error('price')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                    @enderror
                                </div>

                                <div class="col-md-4">
                                    <label for="photo_file">Bahan Dibutuhkan</label>
                                </div>
                                <div class="col-md-8 form-group mb-4">
                                    <div id="ingredients"></div>

                                    <div class="col-12 d-flex justify-content-end">
                                        <button type="button" class="btn btn-info" id="add-ingredient">Tambah Bahan</button>
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <label for="photo_file">Foto Produk</label>
                                </div>
                                <div class="col-md-8 form-group">
                                    <div class="form-file @error('photo_file') is-invalid @enderror">
                                        <input type="file" class="form-file-input" id="photo_file" name="photo_file">
                                        <label class="form-file-label" for="photo_file">
                                            <span class="form-file-text">Pilih foto produk...</span>
                                            <span class="form-file-button">Browse</span>
                                        </label>
                                    </div>
                                    @error('photo_file')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                    @enderror
                                </div>

                                <div class="col-sm-12 d-flex justify-content-end">
                                    <button type="submit" class="btn btn-primary me-1 mb-1">Ubah</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection

@push('body:scripts')
    <div id="ingredient-input-template" class="input-group mb-2 d-none">
        <select class="form-select" name="">
            @forelse($ingredients as $ingredient)
                <option value="{{ $ingredient->id }}">{{ $ingredient->name }}</option>
            @empty
                <option disabled>Tidak ada bahan</option>
            @endforelse
        </select>

        <input type="number" class="form-control" name="" placeholder="Jumlah bahan">

        <a href="#" class="btn icon btn-outline-danger">
            <i data-feather="trash-2"></i>
        </a>
    </div>

    <script src="{{ asset('assets/vendors/choices.js/choices.min.js') }}"></script>

    <script type="text/javascript">
        document.addEventListener('DOMContentLoaded', function () {
            let ingredientIndex = 0;
            const ingredientContainer = document.getElementById('ingredients')
            const ingredientInputTemplate = document.getElementById('ingredient-input-template')

            function addIngredientWithValue(id, quantity) {
                const cloneEl = ingredientInputTemplate.cloneNode(true);

                cloneEl.id = `ingredients-${ingredientIndex}`;
                cloneEl.classList.remove('d-none')

                cloneEl.querySelector('select').name = `ingredients[${ingredientIndex}][id]`

                for (let a = 0; a < cloneEl.querySelector('select').options.length; a++) {
                    if (cloneEl.querySelector('select').options.item(a).value == id) {
                        cloneEl.querySelector('select').selectedIndex = a
                        break
                    }
                }

                cloneEl.querySelector('input').name = `ingredients[${ingredientIndex}][quantity]`
                cloneEl.querySelector('input').value = quantity
                cloneEl.querySelector('a').addEventListener('click', function (e) {
                    e.preventDefault();

                    document.getElementById(cloneEl.id).remove();
                })

                ingredientContainer.appendChild(cloneEl)

                ingredientIndex++

                feather.replace();
            }

            @foreach($product->ingredients as $ingredient)
            addIngredientWithValue({{ $ingredient->id }}, {{ $ingredient->pivot->quantity }});
            @endforeach

            document.getElementById('add-ingredient').addEventListener('click', function (e) {
                e.preventDefault();

                const cloneEl = ingredientInputTemplate.cloneNode(true);

                cloneEl.id = `ingredients-${ingredientIndex}`;
                cloneEl.classList.remove('d-none')
                cloneEl.querySelector('select').name = `ingredients[${ingredientIndex}][id]`
                cloneEl.querySelector('input').name = `ingredients[${ingredientIndex}][quantity]`
                cloneEl.querySelector('a').addEventListener('click', function (e) {
                    e.preventDefault();

                    document.getElementById(cloneEl.id).remove();
                })

                ingredientContainer.appendChild(cloneEl)

                ingredientIndex++

                feather.replace();
            });
        });
    </script>
@endpush
