@extends('layouts.app')

@section('head:title', 'Pemasukan Bahan')

@section('sidebar:ingredients', 'active')

@section('app:content')
    @include('includes.header', ['title' => 'Pemasukan Bahan', 'paragraph' => 'Input bahan yang masuk'])

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <div class="col-sm-12 d-flex justify-content-end">
                        <a href="{{ route('admin.ingredients.inputs.new') }}" class="btn btn-success me-1 mb-1">Input Bahan</a>
                    </div>
                </div>
                <div class="card-content">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead>
                            <tr>
                                <th>NAMA BAHAN</th>
                                <th class="text-center">JUMLAH MASUK</th>
                                <th class="text-center">BIAYA</th>
                                <th class="text-center">TANGGAL INPUT</th>
                                <th class="text-center">DIINPUT OLEH</th>
                            </tr>
                            </thead>
                            <tbody>
                            @forelse($ingredientInputs as $ingredientInput)
                                <tr>
                                    <td>{{ $ingredientInput->ingredient->name }}</td>
                                    <td class="text-center">{{ $ingredientInput->quantity }}</td>
                                    <td class="text-center">Rp {{ number_format($ingredientInput->price) }}</td>
                                    <td class="text-center">{{ $ingredientInput->created_at->format('d-m-Y') }}</td>
                                    <td class="text-center">{{ $ingredientInput->inputtedBy->name }}</td>
                                </tr>
                            @empty
                                <tr>
                                    <th class="text-center" colspan="5">
                                        <span>Tidak ada bahan yang masuk</span>
                                    </th>
                                </tr>
                            @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            {{ $ingredientInputs->links() }}
        </div>
    </div>
@endsection
