@extends('layouts.app')

@section('head:title', 'Input Bahan')

@section('sidebar:ingredients', 'active')

@push('head:scripts')
    <link href="{{ asset('assets/vendors/choices.js/choices.min.css') }}" rel="stylesheet">
@endpush

@section('app:content')
    @include('includes.header', ['title' => 'Input Bahan', 'paragraph' => 'Input bahan yang masuk'])

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4>Form Input Bahan</h4>
                </div>
                <div class="card-body">
                    <form class="form form-horizontal" action="{{ route('admin.ingredients.inputs.create') }}" method="post" enctype="multipart/form-data">
                        @csrf
                        @method('POST')

                        <div class="form-body">
                            <div class="row">
                                <div class="col-md-4">
                                    <label for="ingredient_id">Nama Bahan</label>
                                </div>
                                <div class="col-md-8 form-group mb-4">
                                    <div class="@error('ingredient_id') is-invalid @enderror">
                                        <select class="choices form-select" name="ingredient_id" id="ingredient_id">
                                            @forelse($ingredients as $ingredient)
                                                <option value="{{ $ingredient->id }}" @if(old('ingredient_id') == $ingredient->id) selected @endif>{{ $ingredient->name }} (Stock: {{ $ingredient->current_stock }})</option>
                                            @empty
                                                <option disabled>Tidak ada bahan</option>
                                            @endforelse
                                        </select>
                                    </div>

                                    @error('ingredient_id')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                    @enderror
                                </div>

                                <div class="col-md-4">
                                    <label for="quantity">Jumlah Masuk</label>
                                </div>
                                <div class="col-md-8 form-group mb-4">
                                    <input type="number" min="1" id="quantity" class="form-control @error('quantity') is-invalid @enderror" name="quantity" placeholder="cth: 1000" required value="{{ old('quantity') }}">
                                    @error('quantity')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                    @enderror
                                </div>

                                <div class="col-md-4">
                                    <label for="price">Biaya/Harga</label>
                                </div>
                                <div class="col-md-8 form-group mb-4">
                                    <input type="number" min="0" id="price" class="form-control @error('price') is-invalid @enderror" name="price" placeholder="cth: 1000" required value="{{ old('price') }}">
                                    @error('price')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                    @enderror
                                </div>

                                <div class="col-sm-12 d-flex justify-content-end">
                                    <button type="submit" class="btn btn-primary me-1 mb-1">Tambah</button>
                                    <button type="reset" class="btn btn-light-secondary me-1 mb-1">Reset</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection

@push('body:scripts')
    <script src="{{ asset('assets/vendors/choices.js/choices.min.js') }}"></script>
@endpush
