@extends('layouts.app')

@section('head:title', 'Daftar Bahan')

@section('sidebar:ingredients', 'active')

@section('app:content')
    @include('includes.header', ['title' => 'Daftar Bahan', 'paragraph' => 'Daftar bahan yang digunakan oleh produk'])

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <div class="col-sm-12 d-flex justify-content-end">
                        <a href="{{ route('admin.ingredients.create') }}" class="btn btn-success me-1 mb-1">Tambah Bahan</a>
                    </div>
                </div>
                <div class="card-content">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead>
                            <tr>
                                <th>FOTO</th>
                                <th>NAMA BAHAN</th>
                                <th class="text-center">JUMLAH SEKARANG</th>
                                <th class="text-center">TERKAHIR DIUBAH</th>
                                <th class="text-center">AKSI</th>
                            </tr>
                            </thead>
                            <tbody>
                            @forelse($ingredients as $ingredient)
                                <tr>
                                    <th>
                                        <div class="avatar @unless($ingredient->hasPhoto()) bg-warning @endif avatar-lg ">
                                            @if($ingredient->hasPhoto())
                                                <img src="{{ asset($ingredient->photo_path) }}" alt="{{ $ingredient->name }}">
                                            @else
                                                <div class="avatar-content">
                                                    <i data-feather="image" width="20"></i>
                                                </div>
                                            @endif
                                        </div>
                                    </th>
                                    <td>{{ $ingredient->name }}</td>
                                    <td class="text-center">{{ $ingredient->current_stock }}</td>
                                    <td class="text-center">{{ $ingredient->updated_at->format('d-m-Y H:i') }}</td>
                                    <td class="text-center">
                                        <a href="{{ route('admin.ingredients.edit', compact('ingredient')) }}" class="btn icon btn-outline-info">
                                            <i data-feather="edit" width="20"></i>
                                        </a>

                                        <form class="d-none" action="{{ route('admin.ingredients.delete', compact('ingredient')) }}" method="post" id="form-delete-{{ $ingredient->id }}">
                                            @csrf
                                            @method('DELETE')
                                        </form>

                                        <a href="{{ route('admin.ingredients.delete', compact('ingredient')) }}" class="btn icon btn-outline-danger" onclick="event.preventDefault(); confirm('Apakah anda yakin ingin menghapus bahan ini?') && document.querySelector('#form-delete-{{ $ingredient->id }}').submit();">
                                            <i data-feather="trash" width="20"></i>
                                        </a>
                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <th class="text-center" colspan="5">
                                        <span>Bahan kosong</span>
                                    </th>
                                </tr>
                            @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            {{ $ingredients->links() }}
        </div>
    </div>
@endsection
