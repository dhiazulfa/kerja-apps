@extends('layouts.app')

@section('head:title', 'Tambah Bahan')

@section('sidebar:ingredients', 'active')

@section('app:content')
    @include('includes.header', ['title' => 'Tambah Bahan', 'paragraph' => 'Tambahkan bahan untuk digunakan oleh produk'])

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4>Form Tambah Bahan</h4>
                </div>
                <div class="card-body">
                    <form class="form form-horizontal" action="{{ route('admin.ingredients.create') }}" method="post" enctype="multipart/form-data">
                        @csrf
                        @method('POST')

                        <div class="form-body">
                            <div class="row">
                                <div class="col-md-4">
                                    <label for="name">Nama Bahan</label>
                                </div>
                                <div class="col-md-8 form-group mb-4">
                                    <input type="text" id="name" class="form-control @error('name') is-invalid @enderror" name="name" placeholder="cth: Bubuk Kopi" required value="{{ old('name') }}">
                                    @error('name')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                    @enderror
                                </div>
                                <div class="col-md-4">
                                    <label for="photo_file">Foto Bahan</label>
                                </div>
                                <div class="col-md-8 form-group">
                                    <div class="form-file @error('photo_file') is-invalid @enderror">
                                        <input type="file" class="form-file-input" id="photo_file" name="photo_file">
                                        <label class="form-file-label" for="photo_file">
                                            <span class="form-file-text">Pilih foto bahan...</span>
                                            <span class="form-file-button">Browse</span>
                                        </label>
                                    </div>
                                    @error('photo_file')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                    @enderror
                                </div>
                                <div class="col-sm-12 d-flex justify-content-end">
                                    <button type="submit" class="btn btn-primary me-1 mb-1">Tambah</button>
                                    <button type="reset" class="btn btn-light-secondary me-1 mb-1">Reset</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection
