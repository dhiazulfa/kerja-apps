@extends('layouts.app')

@section('head:title', 'Pengeluaran Bahan')

@section('sidebar:ingredients', 'active')

@section('app:content')
    @include('includes.header', ['title' => 'Pengeluaran Bahan', 'paragraph' => 'Bahan yang sudah digunakan untuk pembuatan produk'])

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-content">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead>
                            <tr>
                                <th>NAMA BAHAN</th>
                                <th class="text-center">JUMLAH KELUAR</th>
                                <th class="text-center">TANGGAL KELUAR</th>
                                <th class="text-center">DIGUNAKAN PRODUK</th>
                                <th class="text-center">PADA ORDER</th>
                            </tr>
                            </thead>
                            <tbody>
                            @forelse($ingredientOutputs as $ingredientOutput)
                                <tr>
                                    <td>{{ $ingredientOutput->ingredient->name }}</td>
                                    <td class="text-center">{{ $ingredientOutput->quantity }}</td>
                                    <td class="text-center">{{ $ingredientOutput->created_at->format('d-m-Y') }}</td>
                                    <td class="text-center">{{ $ingredientOutput->product->name ?? '' }}</td>
                                    <td class="text-center">{{ $ingredientOutput->order->id ?? '' }}</td>
                                </tr>
                            @empty
                                <tr>
                                    <th class="text-center" colspan="5">
                                        <span>Tidak ada bahan yang masuk</span>
                                    </th>
                                </tr>
                            @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            {{ $ingredientOutputs->links() }}
        </div>
    </div>
@endsection
