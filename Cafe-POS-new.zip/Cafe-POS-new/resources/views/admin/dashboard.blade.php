@extends('layouts.app')

@push('head:scripts')
    <link href="{{ asset('assets/vendors/chartjs/Chart.min.css') }}" rel="stylesheet">
@endpush

@section('app:content')
    <div class="row mb-2">
        <div class="col-12 col-md-3">
            <div class="card card-statistic">
                <div class="card-body p-0">
                    <div class="d-flex flex-column">
                        <div class="px-3 py-3 d-flex justify-content-between">
                            <h3 class="card-title">PEMASUKAN</h3>
                            <div class="card-right d-flex align-items-center">
                                @unless($incomes->isEmpty())
                                    <p>Rp {{ number_format($incomes->last()->data / 1000000) }}JT</p>
                                @else
                                    <p>Rp 0</p>
                                @endunless
                            </div>
                        </div>
                        <div class="chart-wrapper">
                            <canvas id="canvas1"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-12 col-md-3">
            <div class="card card-statistic">
                <div class="card-body p-0">
                    <div class="d-flex flex-column">
                        <div class="px-3 py-3 d-flex justify-content-between">
                            <h3 class="card-title">PESANAN</h3>
                            <div class="card-right d-flex align-items-center">
                                <p>{{ !$orders->isEmpty() ? $orders->last()->data : '0' }}</p>
                            </div>
                        </div>
                        <div class="chart-wrapper">
                            <canvas id="canvas2"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-12 col-md-3">
            <div class="card card-statistic">
                <div class="card-body p-0">
                    <div class="d-flex flex-column">
                        <div class="px-3 py-3 d-flex justify-content-between">
                            <h3 class="card-title">PRODUK/MENU</h3>
                            <div class="card-right d-flex align-items-center">
                                <p>{{ $products }}</p>
                            </div>
                        </div>
                        <div class="chart-wrapper">
                            <canvas id="canvas3"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-12 col-md-3">
            <div class="card card-statistic">
                <div class="card-body p-0">
                    <div class="d-flex flex-column">
                        <div class="px-3 py-3 d-flex justify-content-between">
                            <h3 class="card-title">SALES TODAY</h3>
                            <div class="card-right d-flex align-items-center">
                                <p>{{ \App\Order::whereDate('created_at', now()->format('Y-m-d'))->count() }}</p>
                            </div>
                        </div>
                        <div class="chart-wrapper">
                            <canvas id="canvas1"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row mb-4">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-heading p-1 pl-3">Pemasukan Bahan Bulan Ini</h3>
                </div>
                <div class="card-body">
                    <canvas id="ingredient-input"></canvas>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-heading p-1 pl-3">Pengeluaran Bahan Bulan Ini</h3>
                </div>
                <div class="card-body">
                    <canvas id="ingredient-output"></canvas>
                </div>
            </div>
        </div>
    </div>
@endsection

@push('body:scripts')
    <script src="{{ asset('assets/vendors/chartjs/Chart.min.js') }}"></script>

    <script type="text/javascript">
        window.addEventListener('load', function () {
            var randomColor = Math.floor(Math.random() * 16777215).toString(16);
            var chartColors = {
                red: 'rgb(255, 99, 132)',
                orange: 'rgb(255, 159, 64)',
                yellow: 'rgb(255, 205, 86)',
                green: 'rgb(75, 192, 192)',
                info: '#41B1F9',
                blue: '#3245D1',
                purple: 'rgb(153, 102, 255)',
                grey: '#EBEFF6'
            };

            // draws a rectangle with a rounded top
            Chart.helpers.drawRoundedTopRectangle = function (ctx, x, y, width, height, radius) {
                ctx.beginPath();
                ctx.moveTo(x + radius, y);
                // top right corner
                ctx.lineTo(x + width - radius, y);
                ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
                // bottom right	corner
                ctx.lineTo(x + width, y + height);
                // bottom left corner
                ctx.lineTo(x, y + height);
                // top left
                ctx.lineTo(x, y + radius);
                ctx.quadraticCurveTo(x, y, x + radius, y);
                ctx.closePath();
            };

            Chart.elements.RoundedTopRectangle = Chart.elements.Rectangle.extend({
                draw: function () {
                    var ctx = this._chart.ctx;
                    var vm = this._view;
                    var left, right, top, bottom, signX, signY, borderSkipped;
                    var borderWidth = vm.borderWidth;

                    if (!vm.horizontal) {
                        // bar
                        left = vm.x - vm.width / 2;
                        right = vm.x + vm.width / 2;
                        top = vm.y;
                        bottom = vm.base;
                        signX = 1;
                        signY = bottom > top ? 1 : -1;
                        borderSkipped = vm.borderSkipped || 'bottom';
                    } else {
                        // horizontal bar
                        left = vm.base;
                        right = vm.x;
                        top = vm.y - vm.height / 2;
                        bottom = vm.y + vm.height / 2;
                        signX = right > left ? 1 : -1;
                        signY = 1;
                        borderSkipped = vm.borderSkipped || 'left';
                    }

                    // Canvas doesn't allow us to stroke inside the width so we can
                    // adjust the sizes to fit if we're setting a stroke on the line
                    if (borderWidth) {
                        // borderWidth shold be less than bar width and bar height.
                        var barSize = Math.min(Math.abs(left - right), Math.abs(top - bottom));
                        borderWidth = borderWidth > barSize ? barSize : borderWidth;
                        var halfStroke = borderWidth / 2;
                        // Adjust borderWidth when bar top position is near vm.base(zero).
                        var borderLeft = left + (borderSkipped !== 'left' ? halfStroke * signX : 0);
                        var borderRight = right + (borderSkipped !== 'right' ? -halfStroke * signX : 0);
                        var borderTop = top + (borderSkipped !== 'top' ? halfStroke * signY : 0);
                        var borderBottom = bottom + (borderSkipped !== 'bottom' ? -halfStroke * signY : 0);
                        // not become a vertical line?
                        if (borderLeft !== borderRight) {
                            top = borderTop;
                            bottom = borderBottom;
                        }
                        // not become a horizontal line?
                        if (borderTop !== borderBottom) {
                            left = borderLeft;
                            right = borderRight;
                        }
                    }

                    // calculate the bar width and roundess
                    var barWidth = Math.abs(left - right);
                    var roundness = this._chart.config.options.barRoundness || 0.5;
                    var radius = barWidth * roundness * 0.5;

                    // keep track of the original top of the bar
                    var prevTop = top;

                    // move the top down so there is room to draw the rounded top
                    top = prevTop + radius;
                    var barRadius = top - prevTop;

                    ctx.beginPath();
                    ctx.fillStyle = vm.backgroundColor;
                    ctx.strokeStyle = vm.borderColor;
                    ctx.lineWidth = borderWidth;

                    // draw the rounded top rectangle
                    Chart.helpers.drawRoundedTopRectangle(ctx, left, (top - barRadius + 1), barWidth, bottom - prevTop, barRadius);

                    ctx.fill();
                    if (borderWidth) {
                        ctx.stroke();
                    }

                    // restore the original top value so tooltips and scales still work
                    top = prevTop;
                },
            });

            Chart.defaults.roundedBar = Chart.helpers.clone(Chart.defaults.bar);

            Chart.controllers.roundedBar = Chart.controllers.bar.extend({
                dataElementType: Chart.elements.RoundedTopRectangle
            });

            var months = [
                'January',
                'February',
                'March',
                'April',
                'May',
                'June',
                'July',
                'August',
                'September',
                'October',
                'November',
                'December'
            ];

            let canvas1Data = Array.from(@json($incomes->toArray()));
            let canvas2Data = Array.from(@json($orders->toArray()));
            let ingredientInput = @json($ingredientInput->toArray());
            let ingredientOutput = @json($ingredientOutput->toArray());

            new Chart(document.getElementById("canvas1").getContext("2d"), {
                type: "line",
                data: {
                    labels: canvas1Data.map(function (el) {
                        return months[el['month'] - 1];
                    }),
                    datasets: [
                        {
                            label: "Pemasukan",
                            backgroundColor: "#fff",
                            borderColor: "#fff",
                            data: canvas1Data.map(function (el) {
                                return el['data'];
                            }),
                            fill: false,
                            pointBorderWidth: 100,
                            pointBorderColor: "transparent",
                            pointRadius: 3,
                            pointBackgroundColor: "transparent",
                            pointHoverBackgroundColor: "rgba(63,82,227,1)",
                        },
                    ],
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    layout: {
                        padding: {
                            left: -10,
                            top: 10,
                        },
                    },
                    legend: {
                        display: false,
                    },
                    title: {
                        display: false,
                    },
                    tooltips: {
                        mode: "index",
                        intersect: false,
                    },
                    hover: {
                        mode: "nearest",
                        intersect: true,
                    },
                    scales: {
                        xAxes: [
                            {
                                gridLines: {
                                    drawBorder: false,
                                    display: false,
                                },
                                ticks: {
                                    display: false,
                                },
                            },
                        ],
                        yAxes: [
                            {
                                gridLines: {
                                    display: false,
                                    drawBorder: false,
                                },
                                ticks: {
                                    display: false,
                                },
                            },
                        ],
                    },
                },
            });

            new Chart(document.getElementById("canvas2").getContext("2d"), {
                type: "line",
                data: {
                    labels: canvas2Data.map(function (el) {
                        return months[el['month'] - 1];
                    }),
                    datasets: [
                        {
                            label: "Total Pesanan",
                            backgroundColor: "#fff",
                            borderColor: "#fff",
                            data: canvas2Data.map(function (el) {
                                return el['data'];
                            }),
                            fill: false,
                            pointBorderWidth: 100,
                            pointBorderColor: "transparent",
                            pointRadius: 3,
                            pointBackgroundColor: "transparent",
                            pointHoverBackgroundColor: "rgba(63,82,227,1)",
                        },
                    ],
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    layout: {
                        padding: {
                            left: -10,
                            top: 10,
                        },
                    },
                    legend: {
                        display: false,
                    },
                    title: {
                        display: false,
                    },
                    tooltips: {
                        mode: "index",
                        intersect: false,
                    },
                    hover: {
                        mode: "nearest",
                        intersect: true,
                    },
                    scales: {
                        xAxes: [
                            {
                                gridLines: {
                                    drawBorder: false,
                                    display: false,
                                },
                                ticks: {
                                    display: false,
                                },
                            },
                        ],
                        yAxes: [
                            {
                                gridLines: {
                                    display: false,
                                    drawBorder: false,
                                },
                                ticks: {
                                    display: false,
                                },
                            },
                        ],
                    },
                },
            });

            function getRandomColor() {
                var letters = "0123456789ABCDEF".split("");
                var color = "#";
                for (var i = 0; i < 6; i++) {
                    color += letters[Math.floor(Math.random() * 16)];
                }
                return color;
            }

            new Chart(document.getElementById("ingredient-input").getContext("2d"), {
                type: 'bar',
                data: {
                    labels: Object.keys(ingredientInput),
                    datasets: [{
                        label: 'Jumlah',
                        backgroundColor: Object.values(ingredientInput).map(e => getRandomColor()),
                        data: Object.values(ingredientInput),
                    }]
                },
                options: {
                    responsive: true,
                    barRoundness: 1,
                    title: {
                        display: false,
                        text: "Chart.js - Bar Chart with Rounded Tops (drawRoundedTopRectangle Method)"
                    },
                    legend: {
                        display: false
                    },
                    scales: {
                        yAxes: [{
                            ticks: {
                                beginAtZero: true,
                                suggestedMax: 40 + 20,
                                padding: 10,
                            },
                            gridLines: {
                                drawBorder: false,
                            }
                        }],
                        xAxes: [{
                            gridLines: {
                                display: false,
                                drawBorder: false
                            }
                        }]
                    }
                }
            });

            new Chart(document.getElementById("ingredient-output").getContext("2d"), {
                type: 'bar',
                data: {
                    labels: Object.keys(ingredientOutput),
                    datasets: [{
                        label: 'Jumlah',
                        backgroundColor: Object.values(ingredientOutput).map(e => getRandomColor()),
                        data: Object.values(ingredientOutput)
                    }]
                },
                options: {
                    responsive: true,
                    barRoundness: 1,
                    title: {
                        display: false,
                        text: "Chart.js - Bar Chart with Rounded Tops (drawRoundedTopRectangle Method)"
                    },
                    legend: {
                        display: false
                    },
                    scales: {
                        yAxes: [{
                            ticks: {
                                beginAtZero: true,
                                suggestedMax: 40 + 20,
                                padding: 10,
                            },
                            gridLines: {
                                drawBorder: false,
                            }
                        }],
                        xAxes: [{
                            gridLines: {
                                display: false,
                                drawBorder: false
                            }
                        }]
                    }
                }
            });
        });
    </script>
@endpush
