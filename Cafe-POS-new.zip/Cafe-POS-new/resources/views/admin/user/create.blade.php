@extends('layouts.app')

@section('head:title', 'Tambah Pengguna')

@section('sidebar:users', 'active')

@section('app:content')
    @include('includes.header', ['title' => 'Tambah Pengguna', 'paragraph' => 'Tambahkan pengguna'])

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4>Form Tambah Pengguna</h4>
                </div>
                <div class="card-body">
                    <form class="form form-horizontal" action="{{ route('admin.users.create') }}" method="post" enctype="multipart/form-data">
                        @csrf
                        @method('POST')

                        <div class="form-body">
                            <div class="row">
                                <div class="col-md-4">
                                    <label for="name">Nama</label>
                                </div>
                                <div class="col-md-8 form-group mb-4">
                                    <input type="text" id="name" class="form-control @error('name') is-invalid @enderror" name="name" placeholder="cth: Farid Stevy" required value="{{ old('name') }}">
                                    @error('name')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                    @enderror
                                </div>

                                <div class="col-md-4">
                                    <label for="username">Username</label>
                                </div>
                                <div class="col-md-8 form-group mb-4">
                                    <input type="text" id="username" class="form-control @error('username') is-invalid @enderror" name="username" placeholder="frdstvy" required value="{{ old('username') }}">
                                    @error('username')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                    @enderror
                                </div>

                                <div class="col-md-4">
                                    <label for="role">Role</label>
                                </div>
                                <div class="col-md-8 form-group mb-4">
                                    <div class="@error('role') is-invalid @enderror">
                                        <select class="choices form-select" name="role" id="role">
                                            @foreach(\App\Enums\UserRole::asSelectArray() as $key => $val)
                                                <option value="{{ $key }}" @if(old('role') == $key) selected @endif>{{ $val }}</option>
                                            @endforeach
                                        </select>
                                    </div>

                                    @error('role')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                    @enderror
                                </div>

                                <div class="col-md-4">
                                    <label for="password">Kata Sandi</label>
                                </div>
                                <div class="col-md-8 form-group mb-4">
                                    <input type="password" id="password" class="form-control @error('password') is-invalid @enderror" name="password" required>
                                    @error('password')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                    @enderror
                                </div>

                                <div class="col-md-4">
                                    <label for="photo_file">Foto</label>
                                </div>
                                <div class="col-md-8 form-group">
                                    <div class="form-file @error('photo_file') is-invalid @enderror">
                                        <input type="file" class="form-file-input" id="photo_file" name="photo_file">
                                        <label class="form-file-label" for="photo_file">
                                            <span class="form-file-text">Pilih foto...</span>
                                            <span class="form-file-button">Browse</span>
                                        </label>
                                    </div>
                                    @error('photo_file')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                    @enderror
                                </div>
                                <div class="col-sm-12 d-flex justify-content-end">
                                    <button type="submit" class="btn btn-primary me-1 mb-1">Tambah</button>
                                    <button type="reset" class="btn btn-light-secondary me-1 mb-1">Reset</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection
