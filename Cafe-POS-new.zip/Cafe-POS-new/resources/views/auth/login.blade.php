@extends('layouts.auth')

@section('head:title', 'NolKoma')

@section('auth:content')
    <div class="container">
        <div class="row">
            <div class="col-md-5 col-sm-12 mx-auto">
                <div class="card pt-4">
                    <div class="card-body">
                        <div class="text-center mb-5">
                            <img src="{{ asset('assets/images/favicon.svg') }}" height="48" class='mb-4'>
                            <h3>Selamat Datang di NolKoma</h3>
                            <p>Silahkan masuk untuk memulai sesi</p>
                        </div>

                        @if(session()->has('alert'))
                            <div class="alert alert-{{ session()->get('alert.type') . ' ' . session()->get('alert.color') }}">{{ session()->get('alert.text') }}</div>
                        @endif

                        <form action="{{ route('auth.login') }}" method="post">
                            @csrf
                            <div class="form-group position-relative has-icon-left">
                                <label for="username">Username</label>
                                <div class="position-relative @error('username') is-invalid @enderror">
                                    <input type="text" class="form-control @error('username') is-invalid @enderror" id="username" name="username" value="{{ old('username') }}">
                                    <div class="form-control-icon">
                                        <i data-feather="user"></i>
                                    </div>
                                </div>
                                @error('username')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                                @enderror
                            </div>
                            <div class="form-group position-relative has-icon-left">
                                <div class="clearfix">
                                    <label for="password">Password</label>
                                </div>
                                <div class="position-relative @error('password') is-invalid @enderror">
                                    <input type="password" class="form-control @error('password') is-invalid @enderror" id="password" name="password">
                                    <div class="form-control-icon">
                                        <i data-feather="lock"></i>
                                    </div>
                                </div>
                                @error('password')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                                @enderror
                            </div>

                            <div class="clearfix">
                                <button class="btn btn-primary float-end">Masuk</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
