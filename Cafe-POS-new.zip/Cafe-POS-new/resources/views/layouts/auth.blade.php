@extends('layouts.base')

@section('body:content')
    <div id="auth">
        @yield('auth:content')
    </div>
@endsection
