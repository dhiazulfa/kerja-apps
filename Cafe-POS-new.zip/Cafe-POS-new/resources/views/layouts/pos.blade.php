@extends('layouts.base')

@section('body:content')
@endsection
