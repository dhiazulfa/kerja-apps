@extends('layouts.base')

@push('head:scripts')
    <link rel="stylesheet" href="{{ asset('assets/vendors/perfect-scrollbar/perfect-scrollbar.css') }}">
@endpush

@section('body:content')
    <div id="app">
        @include('includes.sidebar')

        <div id="main">
            @include('includes.navbar')

            <div class="main-content container-fluid">
                @yield('app:content')
            </div>

            @include('includes.footer')
        </div>
    </div>
@endsection

@push('body:scripts')
    <script src="{{ asset('assets/vendors/perfect-scrollbar/perfect-scrollbar.min.js') }}"></script>
@endpush
