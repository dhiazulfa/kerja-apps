@extends('layouts.print')

@section('body')
    <div class="container-fluid py-4">
        <div class="row">
            <div class="col-6">
                <div class="card">
                    <div class="card-body">
                        <h3 class="card-title">
                            Total Pesanan
                        </h3>
                        <h1 class="text-center">
                            {{ $totalOrders }}
                        </h1>
                    </div>
                </div>
            </div>
            <div class="col-6">
                <div class="card">
                    <div class="card-body">
                        <h3 class="card-title">
                            Pemasukan
                        </h3>
                        <h1 class="text-center">
                            Rp {{ number_format($income) }}
                        </h1>
                    </div>
                </div>
            </div>
            <div class="col-12 mt-4">
                <div class="card">
                    <div class="card-body">
                        <h3 class="card-title">
                            Biaya Pengeluaran
                        </h3>
                        <h1 class="text-center">
                            Rp {{ number_format($ingredientInputCost) }}
                        </h1>
                    </div>
                </div>
            </div>
        </div>
        <div class="row mt-4">
            <div class="col-12">
                <h3>Produk Terjual</h3>
                <table class="table table-striped table-bordered">
                    <thead>
                    <tr>
                        <th>Nama Produk</th>
                        <th>Jumlah Terjual</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($orderProducts as $productName => $productSold)
                        <tr>
                            <td>{{ $productName }}</td>
                            <td>{{ $productSold }}</td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
            <div class="col-6">
                <h3>Bahan Masuk</h3>
                <table class="table table-striped table-bordered">
                    <thead>
                    <tr>
                        <th>Nama Bahan</th>
                        <th>Jumlah Masuk</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($ingredientInputs as $ingredientName => $ingredientQuantity)
                        <tr>
                            <td>{{ $ingredientName }}</td>
                            <td>{{ $ingredientQuantity }}</td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
            <div class="col-6">
                <h3>Bahan Digunakan</h3>
                <table class="table table-striped table-bordered">
                    <thead>
                    <tr>
                        <th>Nama Bahan</th>
                        <th>Jumlah Digunakan</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($ingredientOutputs as $ingredientName => $ingredientQuantity)
                        <tr>
                            <td>{{ $ingredientName }}</td>
                            <td>{{ $ingredientQuantity }}</td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <script>
        window.print();
    </script>
@endsection
