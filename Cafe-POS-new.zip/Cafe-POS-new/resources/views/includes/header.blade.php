<div class="page-title">
    <h3>{{ $title }}</h3>
    <p class="text-subtitle text-muted">
        {{ $paragraph }}
    </p>
</div>
