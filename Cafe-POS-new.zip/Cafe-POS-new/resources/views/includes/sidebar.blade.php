<div id="sidebar" class="active">
    <div class="sidebar-wrapper active">
        <div class="sidebar-header">
            <img src="{{ asset("assets/images/logo.svg") }}" alt="" srcset="">
        </div>
        <div class="sidebar-menu">
            <ul class="menu">
                <li class="sidebar-item">
                    <a href="{{ url()->to('/report') }}" class="sidebar-link">
                        <i data-feather="archive" width="20"></i>
                        <span>Laporan Bulan Ini</span>
                    </a>
                </li>

                @if(auth()->user()->role->in([\App\Enums\UserRole::Administrator, \App\Enums\UserRole::Cashier]))
                    <li class="sidebar-item @yield('sidebar:orders')">
                        <a href="{{ route('orders.list') }}" class="sidebar-link">
                            <i data-feather="check-circle" width="20"></i>
                            <span>Pesanan</span>
                        </a>
                    </li>
                @endif

                @if(auth()->user()->role->in([\App\Enums\UserRole::Administrator]))
                    <li class="sidebar-title">Main Menu</li>
                    <li class="sidebar-item @yield('sidebar:dashboard')">
                        <a href="{{ route('admin.dashboard') }}" class="sidebar-link">
                            <i data-feather="home" width="20"></i>
                            <span>Dashboard</span>
                        </a>
                    </li>
                    <li class="sidebar-item has-sub @yield('sidebar:ingredients')">
                        <a href="#" class="sidebar-link">
                            <i data-feather="box" width="20"></i>
                            <span>Kelola Bahan</span>
                        </a>
                        <ul class="submenu @yield('sidebar:ingredients')">
                            <li>
                                <a href="{{ route('admin.ingredients.list') }}">Daftar Bahan</a>
                            </li>
                            <li>
                                <a href="{{ route('admin.ingredients.create') }}">Tambah Bahan</a>
                            </li>
                            <li>
                                <a href="{{ route('admin.ingredients.inputs.list') }}">Pemasukan Bahan</a>
                            </li>

                            <li>
                                <a href="{{ route('admin.ingredients.outputs.list') }}">Pengeluaran Bahan</a>
                            </li>
                        </ul>
                    </li>
                    <li class="sidebar-item has-sub @yield('sidebar:products')">
                        <a href="#" class="sidebar-link">
                            <i data-feather="coffee" width="20"></i>
                            <span>Kelola Produk</span>
                        </a>
                        <ul class="submenu @yield('sidebar:products')">
                            <li>
                                <a href="{{ route('admin.products.list') }}">Daftar Produk</a>
                            </li>
                            <li>
                                <a href="{{ route('admin.products.create') }}">Buat Produk Baru</a>
                            </li>
                        </ul>
                    </li>

                    <li class="sidebar-item has-sub @yield('sidebar:users')">
                        <a href="#" class="sidebar-link">
                            <i data-feather="users" width="20"></i>
                            <span>Kelola Pengguna</span>
                        </a>
                        <ul class="submenu @yield('sidebar:users')">
                            <li>
                                <a href="{{ route('admin.users.list') }}">Daftar Pengguna</a>
                            </li>
                            <li>
                                <a href="{{ route('admin.users.create') }}">Tambah Pengguna Baru</a>
                            </li>
                        </ul>
                    </li>
                @endif
            </ul>
        </div>
        <button class="sidebar-toggler btn x"><i data-feather="x"></i></button>
    </div>
</div>
