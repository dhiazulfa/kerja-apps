<footer>
    <div class="footer clearfix mb-0 text-muted">
        <div class="float-start">
            <p>{{ date('Y') }} &copy; {{ config('app.name') }}</p>
        </div>
        <div class="float-end">
            <p>Build with <span class='text-danger'><i data-feather="heart"></i></span> for everyone</p>
        </div>
    </div>
</footer>
