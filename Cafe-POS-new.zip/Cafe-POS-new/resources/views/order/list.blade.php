@extends('layouts.app')

@section('head:title', 'Daftar Pesanan')

@section('sidebar:orders', 'active')

@section('app:content')
    @include('includes.header', ['title' => 'Daftar Pesanan', 'paragraph' => 'Daftar pesanan'])

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <div class="col-sm-12 d-flex justify-content-end">
                        <a href="{{ route('orders.create') }}" class="btn btn-success me-1 mb-1">Buat Pesanan</a>
                    </div>
                </div>
                <div class="card-content">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead>
                            <tr>
                                <th>NAMA PEMBELI</th>
                                <th class="text-center">CATATAN</th>
                                <th>ITEM</th>
                                <th class="text-center">TOTAL HARGA</th>
                                <th class="text-center">DIPESAN PADA</th>
                                <th class="text-center">STATUS</th>
                                <th class="text-center">AKSI</th>
                            </tr>
                            </thead>
                            <tbody>
                            @forelse($orders as $order)
                                <tr>
                                    <td>{{ $order->customer_name }}</td>
                                    <td class="text-center">{{ $order->note }}</td>
                                    <td>
                                        @foreach($order->products as $product)
                                            <li>{{ $product->name }} &times; {{ $product->pivot->quantity }}</li>
                                        @endforeach
                                    </td>
                                    <td class="text-center">Rp {{ number_format($order->total_price) }}</td>
                                    <td class="text-center">{{ $order->created_at->format('d-m-Y') }}</td>
                                    <td class="text-center">{{ $order->status->key }}</td>
                                    <td class="text-center">
                                        <a href="{{ route('orders.print', compact('order')) }}" class="btn icon btn-outline-info">
                                            <i data-feather="printer" width="20"></i>
                                        </a>
                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <th class="text-center" colspan="7">
                                        <span>Pesanan kosong</span>
                                    </th>
                                </tr>
                            @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            {{ $orders->links() }}
        </div>
    </div>
@endsection
