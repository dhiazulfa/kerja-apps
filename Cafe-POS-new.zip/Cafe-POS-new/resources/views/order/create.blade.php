@extends('layouts.app')

@section('head:title', 'Pesanan')

@section('sidebar', '')

@section('sidebar:orders', 'active')

@section('app:content')
    <div class="row">
        <div class="col-8">
            <div class="card">
                <div class="card-header">
                    <h4>Daftar Menu</h4>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-3">
                            <div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                                @foreach($products as $productType => $items)
                                    <a class="nav-link @if($loop->first) active @endif my-2" id="v-pills-{{ $productType }}-tab" data-bs-toggle="pill" href="#v-pills-{{ $productType }}" role="tab" aria-controls="v-pills-{{ $productType }}" aria-selected="true">{{ strtoupper($productType) }}</a>
                                @endforeach
                            </div>
                        </div>
                        <div class="col-9">
                            <div class="tab-content" id="v-pills-tabContent">
                                @foreach($products as $productType => $items)
                                    <div class="tab-pane fade @if($loop->first) active show @endif" id="v-pills-{{ $productType }}" role="tabpanel" aria-labelledby="v-pills-{{ $productType }}-tab">
                                        <div class="row">
                                            @forelse($items as $item)
                                                <div class="col-6">
                                                    <div class="card">
                                                        <div class="card-content">
                                                            <img class="card-img-top img-fluid" style="object-fit: cover; height: 128px" src="{{ asset($item->hasPhoto() ? $item->photo_path : 'assets/images/samples/aerial-panoramic-image-of-sansonvale-lake-X6TCENW.jpg') }}" alt="Card image cap">
                                                            <div class="card-body">
                                                                <h5 class="card-title">
                                                                    {{ $item->name }}

                                                                    @unless($item->is_available)
                                                                        <span class="badge bg-warning">{{ $item->insufficient_ingredient_name }} Habis</span>
                                                                    @endunless
                                                                </h5>
                                                                <p class="card-text">Rp {{ number_format($item->price) }}</p>
                                                                <form action="{{ route('orders.items.add') }}" method="post">
                                                                    @csrf

                                                                    <input type="hidden" name="products[{{ $item->id }}][id]" value="{{ $item->id }}">
                                                                    <input type="number" class="form-control mb-2 " @unless($item->is_available) disabled @endunless name="products[{{ $item->id }}][quantity]" placeholder="Jumlah">
                                                                    <button class="btn btn-primary block @unless($item->is_available) disabled @endunless">Tambahkan</button>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            @empty
                                            @endforelse
                                        </div>
                                    </div>
                                @endforeach
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-4">
            <div class="card">
                <div class="card-header">
                    <h4>Pesanan</h4>
                </div>

                <div class="card-body">
                    <form method="post" action="{{ route('orders.create') }}">
                        @csrf

                        <div class="form-group">
                            <label for="customer-name">Nama Pembeli</label>
                            <input type="text" id="customer-name" class="form-control" name="customer_name" placeholder="">
                        </div>

                        <div class="form-group">
                            <label for="note">Catatan</label>
                            <input type="text" id="note" class="form-control" name="note" placeholder="">
                        </div>

                        <p class="font-bold card-text">Rincian</p>

                        <ul class="list-group list-group-flush">
                            @forelse($orderItems as $item)
                                <input type="hidden" name="products[{{ $loop->index }}][id]" value="{{ $item['id'] }}">
                                <input type="hidden" name="products[{{ $loop->index }}][quantity]" value="{{ $item['quantity'] }}">

                                @if($loop->first)
                                    <li class="list-group-item d-flex justify-content-between">
                                        <span>Nama</span>
                                        <span>Total Harga</span>
                                    </li>
                                @endif

                                <li class="list-group-item d-flex justify-content-between">
                                    <span>{{ $item['name'] }} &times; {{ $item['quantity'] }}</span>
                                    <span>Rp {{ number_format($item['total_price']) }}</span>
                                </li>

                                @if($loop->last)
                                    <li class="list-group-item d-flex justify-content-between font-bold">
                                        <span>PPn {{ config('cafe.order_tax', 10) }}%</span>
                                        <span>Rp {{ number_format((config('cafe.order_tax', 10) / 100) * $orderItems->sum('total_price')) }}</span>
                                    </li>
                                    <li class="list-group-item d-flex justify-content-between font-bold">
                                        <span>Total</span>
                                        <span>Rp {{ number_format($orderItems->sum('total_price') + (config('cafe.order_tax', 10) / 100) * $orderItems->sum('total_price')) }}</span>
                                    </li>
                                @endif
                            @empty
                            @endforelse
                        </ul>

                        <div class="my-2">
                            <button type="submit" class="btn btn-block btn-primary @if($orderItems->isEmpty()) disabled @endif">Selesaikan Pesanan</button>
                        </div>
                    </form>

                    <form action="{{ route('orders.items.reset') }}" method="post">
                        @csrf
                        @method('DELETE')

                        <div class="my-2">
                            <button type="submit" class="btn btn-block btn-danger @if($orderItems->isEmpty()) disabled @endif">Reset Pesanan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection

@push('body:scripts')

@endpush
