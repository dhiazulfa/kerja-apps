@extends('layouts.print')

@section('body')
    <div class="container-fluid py-4">
        <div class="d-flex justify-content-between">
            <p>Customer Name: {{ $order->customer_name }}</p>
            <p>Tanggal: {{ $order->created_at }}</p>
        </div>
        <div class="d-flex justify-content-between">
            <p>Note: {{ $order->note }}</p>
        </div>

        <div class="row mt-4">
            <div class="col-12">
                <h3>Item</h3>
                <table class="table table-striped table-bordered">
                    <thead>
                    <tr>
                        <th>Nama</th>
                        <th class="text-end">Qty</th>
                        <th class="text-end">Harga</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($order->products as $product)
                        <tr>
                            <td>{{ $product->name }}</td>
                            <td class="text-end">{{ $product->pivot->quantity }}</td>
                            <td class="text-end">Rp {{ number_format($product->pivot->quantity * $product->price) }}</td>
                        </tr>
                    @endforeach
                    <tr>
                        <td colspan="2" class="text-end">Harga Total + PPn {{ $order->tax }}%</td>
                        <td class="text-end">Rp {{ number_format($order->total_price) }}</td>
                    </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <script>
        window.print();
    </script>
@endsection
