<?php

return [
    'order_tax' => env('ORDER_TAX', 10),
];
